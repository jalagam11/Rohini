#include "console.h"
void main() 
{
	clear_terminal();
	print_character('H');
	print_string("ello");
	print_line("world");
	print_string("TODAY");
	return;
}
